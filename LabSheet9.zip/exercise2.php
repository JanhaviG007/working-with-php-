<?php
// Database credentials
$servername = "127.0.0.1";
$username   = "root";
$password   = "";        // Use "root" if on MAMP
$dbname     = "ecs417";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Retrieve and sanitise form data
    $fname  = $conn->real_escape_string(trim($_POST['firstName']  ?? ''));
    $sname  = $conn->real_escape_string(trim($_POST['surname']    ?? ''));
    $email  = $conn->real_escape_string(trim($_POST['email']      ?? ''));
    $pass1  = trim($_POST['password']        ?? '');
    $pass2  = trim($_POST['confirmPassword'] ?? '');

    $errors = [];

    // Server-side validation
    if (empty($fname)) {
        $errors[] = "First name is required.";
    }
    if (empty($sname)) {
        $errors[] = "Surname is required.";
    }
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "A valid email address is required.";
    }
    if (empty($pass1)) {
        $errors[] = "Password cannot be blank.";
    }
    if ($pass1 !== $pass2) {
        $errors[] = "Passwords do not match.";
    }

    if (!empty($errors)) {
        // Display errors
        echo "<!DOCTYPE html><html lang='en'><head><meta charset='UTF-8'>
              <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css'>
              <title>Registration Error</title></head>
              <body style='background:#00bcd4;display:flex;justify-content:center;align-items:center;min-height:100vh;'>
              <div style='background:white;padding:40px;border-radius:8px;min-width:380px;'>
              <h2 class='text-center'>User Registration Form</h2>
              <div class='alert alert-danger'>";
        foreach ($errors as $err) {
            echo "<p class='mb-1'>&#10007; " . htmlspecialchars($err) . "</p>";
        }
        echo "</div><a href='exercise2.html' class='btn btn-primary'>Go Back</a>
              </div></body></html>";
        $conn->close();
        exit;
    }

    // Hash the password before storing
    $hashed_password = password_hash($pass1, PASSWORD_BCRYPT);
    $hashed_password = $conn->real_escape_string($hashed_password);

    // Insert into database
    $sql = "INSERT INTO USERS (firstName, lastName, email, password)
            VALUES ('$fname', '$sname', '$email', '$hashed_password')";

    if ($conn->query($sql) === TRUE) {
        // Registration successful
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Topic 9 - Exercise 6</title>
            <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
            <style>
                body {
                    background-color: #00bcd4;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    min-height: 100vh;
                }
                .card {
                    padding: 40px;
                    min-width: 380px;
                    text-align: center;
                }
            </style>
        </head>
        <body>
            <div class="card">
                <h2>User Registration Form</h2>
                <p class="text-success fw-bold">Registration Successful</p>
                <a href="exercise3.php" class="btn btn-primary">Home</a>
            </div>
        </body>
        </html>
        <?php
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
