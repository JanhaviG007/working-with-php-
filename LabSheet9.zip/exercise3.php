<?php
session_start();

// Database credentials
$servername = "127.0.0.1";
$username   = "root";
$password   = "";        // Use "root" if on MAMP
$dbname     = "ecs417";

$error_message = "";

// Handle POST login submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $email      = trim($_POST['email']    ?? '');
    $input_pass = trim($_POST['password'] ?? '');

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Sanitise email before querying
    $safe_email = $conn->real_escape_string($email);

    // Look up user by email
    $sql    = "SELECT ID, password FROM USERS WHERE email = '$safe_email' LIMIT 1";
    $result = $conn->query($sql);

    if ($result && $result->num_rows === 1) {
        $row = $result->fetch_assoc();

        // Verify hashed password
        if (password_verify($input_pass, $row['password'])) {
            // Successful login — start session
            $_SESSION['UserID'] = $row['ID'];
            $_SESSION['email']  = htmlspecialchars($email);
        } else {
            $error_message = "Invalid email or password. Please try again.";
        }
    } else {
        $error_message = "Invalid email or password. Please try again.";
    }

    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Topic 9 - Exercise 3</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #00bcd4;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .card {
            background: white;
            padding: 40px;
            border-radius: 8px;
            min-width: 380px;
            max-width: 460px;
            width: 100%;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="card">
        <?php if (isset($_SESSION['UserID'])): ?>
            <!-- User is logged in -->
            <h2>Welcome Back</h2>
            <a href="logout.php">Logout</a>

        <?php else: ?>
            <!-- Show login form -->
            <h2>Login</h2>

            <?php if (!empty($error_message)): ?>
                <div class="alert alert-danger"><?php echo htmlspecialchars($error_message); ?></div>
            <?php endif; ?>

            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">

                <div class="mb-3 text-start">
                    <label for="email" class="form-label" style="color: #00bcd4; font-weight: bold;">Email address</label>
                    <input type="email" class="form-control" id="email" name="email"
                           placeholder="p.parker@dailybugle.com" required>
                </div>

                <div class="mb-4 text-start">
                    <label for="password" class="form-label" style="color: #00bcd4; font-weight: bold;">Password</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>

                <div class="d-grid">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>

            </form>

            <p class="mt-3">
                Don't have an account? <a href="exercise2.html">Register here</a>
            </p>

        <?php endif; ?>
    </div>
</body>
</html>
