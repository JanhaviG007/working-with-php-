<?php
// Bulb descriptions mapped by price
$bulb_descriptions = [
    "2.39" => "Four 100-watt light bulbs",
    "4.29" => "Eight 100-watt light bulbs",
    "3.95" => "Four 100-watt long-life light bulbs",
    "7.49" => "Eight 100-watt long-life light bulbs"
];

// Retrieve POST data
$name         = isset($_POST['name']) ? htmlspecialchars($_POST['name']) : 'Unknown';
$selected_bulbs = isset($_POST['bulbs']) ? $_POST['bulbs'] : [];
$battery_packs  = isset($_POST['battery_packs']) ? (int)$_POST['battery_packs'] : 0;
$credit_card    = isset($_POST['credit_card']) ? htmlspecialchars($_POST['credit_card']) : 'Not selected';

// Calculate subtotal
$subtotal = 0.0;

foreach ($selected_bulbs as $price) {
    $subtotal += (float)$price;
}

$battery_cost = $battery_packs * 10.42;
$subtotal += $battery_cost;

// Add 20% VAT
$vat_rate   = 0.20;
$vat_amount = $subtotal * $vat_rate;
$total      = $subtotal + $vat_amount;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Summary</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 650px;
            margin: 40px auto;
            padding: 20px;
            background-color: #f4f4f4;
        }
        h1 { text-align: center; color: #333; }
        p  { font-size: 16px; }
        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #fff;
            margin-top: 20px;
        }
        th {
            background-color: #0056b3;
            color: white;
            padding: 10px;
            text-align: left;
        }
        td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }
        tr:last-child td { border-bottom: none; }
        .total-row td {
            font-weight: bold;
            background-color: #e8f0fe;
        }
        .back-link {
            display: inline-block;
            margin-top: 20px;
            padding: 8px 16px;
            background-color: #0056b3;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }
        .back-link:hover { background-color: #003d80; }
        .no-items { color: #888; font-style: italic; }
    </style>
</head>
<body>
    <h1>Order Summary</h1>
    <p>Thank you, <strong><?php echo $name; ?></strong>! Here is a summary of your order:</p>

    <table>
        <thead>
            <tr>
                <th>Item</th>
                <th>Price</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($selected_bulbs) && $battery_packs <= 0): ?>
                <tr>
                    <td colspan="2" class="no-items">No items selected.</td>
                </tr>
            <?php else: ?>
                <?php foreach ($selected_bulbs as $price): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($bulb_descriptions[$price] ?? 'Unknown item'); ?></td>
                        <td>&pound;<?php echo number_format((float)$price, 2); ?></td>
                    </tr>
                <?php endforeach; ?>

                <?php if ($battery_packs > 0): ?>
                    <tr>
                        <td>Battery Packs &times; <?php echo $battery_packs; ?> (&pound;10.42 each)</td>
                        <td>&pound;<?php echo number_format($battery_cost, 2); ?></td>
                    </tr>
                <?php endif; ?>
            <?php endif; ?>

            <!-- Subtotal -->
            <tr>
                <td>Subtotal (before VAT)</td>
                <td>&pound;<?php echo number_format($subtotal, 2); ?></td>
            </tr>

            <!-- VAT -->
            <tr>
                <td>VAT (20%)</td>
                <td>&pound;<?php echo number_format($vat_amount, 2); ?></td>
            </tr>

            <!-- Total -->
            <tr class="total-row">
                <td>Total (inc. VAT)</td>
                <td>&pound;<?php echo number_format($total, 2); ?></td>
            </tr>
        </tbody>
    </table>

    <p><strong>Payment Method:</strong> <?php echo $credit_card; ?></p>

    <a href="exercise1.html" class="back-link">&larr; Back to Order Form</a>
</body>
</html>
