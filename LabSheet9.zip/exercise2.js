/**
 * exercise2.js
 * Validates the Password and Confirm Password fields:
 *  - Neither field may be blank
 *  - Both fields must match
 * Uses addEventListener as required by the assessment criteria.
 */

document.addEventListener("DOMContentLoaded", function () {

    const form            = document.getElementById("registrationForm");
    const passwordField   = document.getElementById("password");
    const confirmField    = document.getElementById("confirmPassword");
    const passwordError   = document.getElementById("passwordError");
    const confirmError    = document.getElementById("confirmPasswordError");

    /**
     * Validates both password fields.
     * Returns true if valid, false otherwise.
     */
    function validatePasswords() {
        let valid = true;

        // Reset error messages
        passwordError.textContent = "";
        confirmError.textContent  = "";

        const pwd     = passwordField.value.trim();
        const confirm = confirmField.value.trim();

        // Check password is not blank
        if (pwd === "") {
            passwordError.textContent = "Password cannot be blank.";
            valid = false;
        }

        // Check confirm password is not blank
        if (confirm === "") {
            confirmError.textContent = "Please confirm your password.";
            valid = false;
        }

        // Check both passwords match (only if neither is blank)
        if (pwd !== "" && confirm !== "" && pwd !== confirm) {
            confirmError.textContent = "Passwords do not match.";
            valid = false;
        }

        return valid;
    }

    // Live validation: check as user types in confirm field
    confirmField.addEventListener("input", function () {
        validatePasswords();
    });

    // Live validation: re-check when password field changes
    passwordField.addEventListener("input", function () {
        validatePasswords();
    });

    // Prevent form submission if passwords are invalid
    form.addEventListener("submit", function (event) {
        if (!validatePasswords()) {
            event.preventDefault();
        }
    });

});
