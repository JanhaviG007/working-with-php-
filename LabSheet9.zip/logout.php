<?php
// Start session so we can access and destroy it
session_start();

// Store the referring page before we destroy session data
$referer = $_SERVER['HTTP_REFERER'] ?? 'exercise3.php';

// Reset all session variables
$_SESSION = [];

// Destroy the session cookie if it exists
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params["path"],
        $params["domain"],
        $params["secure"],
        $params["httponly"]
    );
}

// Destroy the session
session_destroy();

// Redirect back to the page the logout link was clicked from
header("Location: " . $referer);
exit;
?>
